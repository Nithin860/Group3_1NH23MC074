package com.innoverasolutions.resource_management.controller;

import com.innoverasolutions.resource_management.model.Feedback;
import com.innoverasolutions.resource_management.repository.FeedbackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class FeedbackController {

    @Autowired
    private FeedbackRepository feedbackRepository;

    @GetMapping("/feedback")
    public String showFeedbackForm() {
        return "feedback"; // Thymeleaf template name for feedback form
    }

    @PostMapping("/submitFeedback")
    public String submitFeedback(@RequestParam String name,
                                 @RequestParam String email,
                                 @RequestParam String comments,
                                 @RequestParam int rating) {
        Feedback feedback = new Feedback();
        feedback.setName(name);
        feedback.setEmail(email);
        feedback.setComments(comments);
        feedback.setRating(rating);

        feedbackRepository.save(feedback);

        return "redirect:/feedback?success=true"; // Redirect after submission
    }

    @GetMapping("/admin/feedbacks")
    public String viewFeedbacks(Model model) {
        model.addAttribute("feedbackList", feedbackRepository.findAll());
        return "ViewFeedback"; // Thymeleaf template for admin to view feedbacks
    }
}
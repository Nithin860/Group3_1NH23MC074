package com.innoverasolutions.resource_management.service;

import com.innoverasolutions.resource_management.model.Feedback;
import com.innoverasolutions.resource_management.repository.FeedbackRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public interface FeedbackService {
    void submitFeedback(String name, String email, String comments);

    @Autowired
    FeedbackRepository feedbackRepository = null;

    public default List<Feedback> getAllFeedback() {
        return feedbackRepository.findAll();
    }
}

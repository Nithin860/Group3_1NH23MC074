package com.innoverasolutions.resource_management.service;

import com.innoverasolutions.resource_management.model.Feedback;
import com.innoverasolutions.resource_management.repository.FeedbackRepository;
import com.innoverasolutions.resource_management.service.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FeedbackServiceImpl implements FeedbackService {

    @Autowired
    private FeedbackRepository feedbackRepository;

    @Override
    public void submitFeedback(String name, String email, String comments) {
        Feedback feedback = new Feedback();
        feedback.setName(feedback.getName());
        feedback.setEmail(feedback.getEmail());
        feedback.setComments(feedback.getComments());
        feedback.setRating(feedback.getRating());
        feedbackRepository.save(feedback);
    }

}
